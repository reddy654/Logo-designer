export type LogoStyle =
  | 'minimal' | 'luxury' | 'tech' | 'gaming' | 'startup'
  | 'fashion' | 'corporate' | 'neon' | 'mascot' | 'elegant'
  | 'modern' | '3d' | 'flat' | 'gradient' | 'monogram'
  | 'futuristic' | 'vintage' | 'handcrafted' | 'geometric'
  | 'abstract' | 'badge' | 'wordmark' | 'lettermark';

export type Industry =
  | 'technology' | 'fashion' | 'food' | 'gaming' | 'finance'
  | 'health' | 'education' | 'real-estate' | 'travel' | 'beauty'
  | 'sports' | 'music' | 'photography' | 'legal' | 'consulting'
  | 'retail' | 'restaurant' | 'crypto' | 'nft' | 'agency'
  | 'ecommerce' | 'youtube' | 'podcast' | 'fitness' | 'startup';

export type ColorPalette =
  | 'midnight' | 'ocean' | 'sunset' | 'forest' | 'royal'
  | 'rose' | 'gold' | 'monochrome' | 'neon' | 'pastel'
  | 'earth' | 'fire' | 'arctic' | 'cosmic' | 'custom';

export interface LogoConfig {
  businessName: string;
  tagline?: string;
  industry: Industry;
  style: LogoStyle;
  colorPalette: ColorPalette;
  customColors?: string[];
  fontStyle?: string;
  iconPreference?: string;
  creativity: number;
  detailLevel: 'minimal' | 'moderate' | 'detailed';
  mood?: 'professional' | 'playful' | 'bold' | 'elegant' | 'friendly' | 'serious';
}

export interface GeneratedLogo {
  id: string;
  imageUrl: string;
  svgCode?: string;
  prompt: string;
  style: LogoStyle;
  config: LogoConfig;
  createdAt: Date;
  isFavorite?: boolean;
  variants?: LogoVariant[];
  niche_images?: NicheImage[];
}

export interface LogoVariant {
  id: string;
  type: 'horizontal' | 'vertical' | 'icon-only' | 'badge' | 'monogram';
  imageUrl: string;
}

export interface NicheImage {
  id: string;
  url: string;
  description: string;
  photographer?: string;
}

export interface MockupType {
  id: string;
  name: string;
  image: string;
  category: 'print' | 'digital' | 'apparel' | 'packaging';
}

export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  interval: 'month' | 'year';
  features: string[];
  limit?: number;
  popular?: boolean;
}

export interface ColorPaletteOption {
  id: ColorPalette;
  name: string;
  colors: string[];
  gradient: string;
}

export const COLOR_PALETTES: ColorPaletteOption[] = [
  { id: 'midnight', name: 'Midnight', colors: ['#0f0f1a', '#1a1a3e', '#6366f1', '#8b5cf6'], gradient: 'linear-gradient(135deg, #0f0f1a, #6366f1)' },
  { id: 'ocean', name: 'Ocean', colors: ['#0c1445', '#1e40af', '#0ea5e9', '#06b6d4'], gradient: 'linear-gradient(135deg, #0c1445, #06b6d4)' },
  { id: 'sunset', name: 'Sunset', colors: ['#1a0a00', '#9a3412', '#f97316', '#fbbf24'], gradient: 'linear-gradient(135deg, #9a3412, #fbbf24)' },
  { id: 'forest', name: 'Forest', colors: ['#052e16', '#166534', '#16a34a', '#4ade80'], gradient: 'linear-gradient(135deg, #052e16, #4ade80)' },
  { id: 'royal', name: 'Royal', colors: ['#1e0038', '#4c1d95', '#7c3aed', '#a78bfa'], gradient: 'linear-gradient(135deg, #1e0038, #a78bfa)' },
  { id: 'rose', name: 'Rose', colors: ['#1a0010', '#9f1239', '#e11d48', '#fb7185'], gradient: 'linear-gradient(135deg, #9f1239, #fb7185)' },
  { id: 'gold', name: 'Gold', colors: ['#1a1000', '#92400e', '#d97706', '#fbbf24'], gradient: 'linear-gradient(135deg, #92400e, #fbbf24)' },
  { id: 'monochrome', name: 'Monochrome', colors: ['#000000', '#374151', '#9ca3af', '#ffffff'], gradient: 'linear-gradient(135deg, #000, #fff)' },
  { id: 'neon', name: 'Neon', colors: ['#000000', '#00ff41', '#00d4ff', '#ff006e'], gradient: 'linear-gradient(135deg, #00ff41, #ff006e)' },
  { id: 'cosmic', name: 'Cosmic', colors: ['#03001c', '#7b2fbe', '#ff6b6b', '#ffd93d'], gradient: 'linear-gradient(135deg, #03001c, #ff6b6b)' },
  { id: 'arctic', name: 'Arctic', colors: ['#e0f7fa', '#80deea', '#26c6da', '#00838f'], gradient: 'linear-gradient(135deg, #e0f7fa, #00838f)' },
  { id: 'fire', name: 'Fire', colors: ['#1a0000', '#7f1d1d', '#dc2626', '#fca5a5'], gradient: 'linear-gradient(135deg, #7f1d1d, #fca5a5)' },
];

export const LOGO_STYLES: { id: LogoStyle; name: string; description: string; icon: string }[] = [
  { id: 'minimal', name: 'Minimal', description: 'Clean & simple', icon: '◻' },
  { id: 'luxury', name: 'Luxury', description: 'Premium & refined', icon: '◆' },
  { id: 'tech', name: 'Tech', description: 'Digital & precise', icon: '⬡' },
  { id: 'gaming', name: 'Gaming', description: 'Bold & energetic', icon: '◈' },
  { id: 'startup', name: 'Startup', description: 'Modern & fresh', icon: '◲' },
  { id: 'fashion', name: 'Fashion', description: 'Elegant & stylish', icon: '◓' },
  { id: 'corporate', name: 'Corporate', description: 'Professional & trustworthy', icon: '▣' },
  { id: 'neon', name: 'Neon', description: 'Glowing & vibrant', icon: '◉' },
  { id: 'gradient', name: 'Gradient', description: 'Smooth color flow', icon: '◐' },
  { id: 'monogram', name: 'Monogram', description: 'Lettermark style', icon: '◫' },
  { id: 'futuristic', name: 'Futuristic', description: 'Sci-fi inspired', icon: '◭' },
  { id: 'vintage', name: 'Vintage', description: 'Classic & timeless', icon: '◎' },
  { id: 'geometric', name: 'Geometric', description: 'Shape-based design', icon: '△' },
  { id: 'abstract', name: 'Abstract', description: 'Artistic & unique', icon: '◌' },
  { id: 'badge', name: 'Badge', description: 'Emblem style', icon: '◊' },
  { id: 'wordmark', name: 'Wordmark', description: 'Text focused', icon: '◁' },
];

export const INDUSTRIES: { id: Industry; name: string; icon: string }[] = [
  { id: 'technology', name: 'Technology', icon: '💻' },
  { id: 'fashion', name: 'Fashion', icon: '👗' },
  { id: 'food', name: 'Food & Beverage', icon: '🍽️' },
  { id: 'gaming', name: 'Gaming', icon: '🎮' },
  { id: 'finance', name: 'Finance', icon: '💰' },
  { id: 'health', name: 'Health & Wellness', icon: '🏥' },
  { id: 'education', name: 'Education', icon: '📚' },
  { id: 'real-estate', name: 'Real Estate', icon: '🏠' },
  { id: 'travel', name: 'Travel', icon: '✈️' },
  { id: 'beauty', name: 'Beauty & Cosmetics', icon: '💄' },
  { id: 'sports', name: 'Sports & Fitness', icon: '⚡' },
  { id: 'music', name: 'Music & Entertainment', icon: '🎵' },
  { id: 'photography', name: 'Photography', icon: '📷' },
  { id: 'consulting', name: 'Consulting', icon: '💼' },
  { id: 'retail', name: 'Retail & E-commerce', icon: '🛍️' },
  { id: 'restaurant', name: 'Restaurant & Cafe', icon: '☕' },
  { id: 'crypto', name: 'Crypto & Web3', icon: '₿' },
  { id: 'agency', name: 'Creative Agency', icon: '🎨' },
  { id: 'youtube', name: 'YouTube Channel', icon: '▶️' },
  { id: 'startup', name: 'Startup', icon: '🚀' },
  { id: 'fitness', name: 'Fitness & Gym', icon: '💪' },
  { id: 'podcast', name: 'Podcast', icon: '🎙️' },
];
