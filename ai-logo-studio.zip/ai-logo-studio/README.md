# LogoStudio AI 🎨

A premium AI-powered logo designer & generator SaaS built with Next.js 15.

## ✨ Features

- **24+ Logo Styles** — Minimal, Luxury, Tech, Gaming, Neon, Futuristic, Vintage, Badge, Monogram, and more
- **22 Industries** — Technology, Fashion, Food, Gaming, Finance, Beauty, Fitness, YouTube, Crypto, and more  
- **12 Color Palettes** — Midnight, Ocean, Sunset, Forest, Royal, Neon, Cosmic, and more
- **6+ Concepts per Generation** — Multiple unique logos every time
- **Logo Variants** — Icon-only, horizontal, badge formats included
- **Niche Imagery** — Curated industry-specific inspiration photos
- **Mockup Previews** — Business card, app icon, website header, t-shirt
- **Export Options** — PNG and SVG downloads
- **Background Removal** — Powered by Remove.bg API
- **Favorites System** — Save your best logos locally
- **Premium UI** — Dark mode, glassmorphism, smooth animations

## 🚀 Quick Start

```bash
# 1. Clone / extract project
cd ai-logo-studio

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your API keys

# 4. Run development server
npm run dev

# 5. Open browser
open http://localhost:3000
```

## 📁 Project Structure

```
ai-logo-studio/
├── app/
│   ├── api/
│   │   ├── generate-logo/route.ts    # Logo generation API
│   │   └── remove-bg/route.ts        # Background removal API
│   ├── auth/
│   │   ├── login/page.tsx            # Login page
│   │   └── signup/page.tsx           # Signup page
│   ├── generator/page.tsx            # Main generator dashboard
│   ├── globals.css                   # Global styles
│   ├── layout.tsx                    # Root layout
│   └── page.tsx                      # Landing page
├── lib/
│   ├── logo-generator.ts             # Core SVG generation logic
│   └── store.ts                      # Zustand state management
├── types/
│   └── index.ts                      # TypeScript types & constants
├── .env.example                      # Environment variables template
├── next.config.js
├── tailwind.config.js
└── tsconfig.json
```

## 🎨 Logo Styles

| Style | Best For |
|-------|----------|
| Minimal | Clean, modern brands |
| Luxury | Premium, high-end products |
| Tech | SaaS, tech startups |
| Gaming | Esports, gaming channels |
| Neon | Nightlife, edgy brands |
| Futuristic | Sci-fi, innovation |
| Geometric | Architecture, design |
| Monogram | Personal brands, agencies |
| Badge | Cafes, local businesses |
| Vintage | Heritage, classic brands |
| Gradient | Modern startups |
| Wordmark | Simple text logos |

## 🔧 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `REMOVE_BG_API_KEY` | Remove.bg API key | Yes |
| `DATABASE_URL` | PostgreSQL connection string | Optional |
| `NEXTAUTH_SECRET` | NextAuth.js secret | For auth |
| `GOOGLE_CLIENT_ID/SECRET` | Google OAuth | For auth |

## 📦 Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **State**: Zustand with persistence
- **Forms**: React Hook Form + Zod
- **Icons**: Lucide React
- **Logo Engine**: Custom SVG generation
- **Background Removal**: Remove.bg API

## 🖥️ Pages

- `/` — Landing page with hero, features, pricing
- `/generator` — Main logo creation dashboard
- `/auth/login` — Sign in
- `/auth/signup` — Create account

## 🎯 How Logo Generation Works

1. User inputs business name, industry, style, and color palette
2. The `generateMultipleLogos()` function creates 6 unique SVG logos
3. Each style has a dedicated SVG generator function
4. Colors are mapped from selected palettes
5. Niche-specific Unsplash images are fetched for inspiration
6. Results include multiple variants (icon-only, horizontal, badge)

## 🚢 Deployment

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
# Follow prompts, set environment variables in Vercel dashboard
```

### Docker
```bash
docker build -t logostudio-ai .
docker run -p 3000:3000 --env-file .env.local logostudio-ai
```

## 🔑 Remove.bg Integration

The background removal feature uses Remove.bg API:

1. Get your API key at [remove.bg](https://www.remove.bg/api)
2. Add it to `.env.local`: `REMOVE_BG_API_KEY=your_key`
3. The secure API route at `/api/remove-bg` handles all requests server-side

## 📝 Adding New Logo Styles

1. Add style to `LOGO_STYLES` array in `types/index.ts`
2. Create SVG generator function in `lib/logo-generator.ts`
3. Register it in the `STYLE_GENERATORS` object

## 🤝 Contributing

PRs welcome! Please open an issue first to discuss major changes.

## 📄 License

MIT License — free for personal and commercial use.

---

Built with ❤️ for founders, creators, and designers.
