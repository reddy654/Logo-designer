import type { LogoConfig, GeneratedLogo, NicheImage } from '@/types';
import { COLOR_PALETTES } from '@/types';

// Unsplash image categories per industry/niche
const NICHE_PHOTO_QUERIES: Record<string, string[]> = {
  technology: ['technology abstract', 'circuit board neon', 'digital code blue', 'cyberpunk tech'],
  fashion: ['fashion runway lights', 'luxury fashion minimal', 'clothing brand aesthetic', 'model editorial'],
  food: ['gourmet food plating', 'coffee shop aesthetic', 'restaurant dark mood', 'food photography'],
  gaming: ['gaming setup neon', 'esports arena lights', 'cyberpunk city', 'game controller neon'],
  finance: ['wall street night', 'gold bars luxury', 'financial charts', 'business skyscraper'],
  health: ['medical clean minimal', 'wellness spa', 'health nature', 'medical technology'],
  education: ['library books', 'university campus', 'learning digital', 'knowledge books'],
  'real-estate': ['luxury mansion', 'modern architecture', 'interior design minimal', 'skyscraper city'],
  travel: ['mountain landscape', 'tropical beach', 'city skyline night', 'travel adventure'],
  beauty: ['cosmetics luxury', 'beauty product flat lay', 'makeup artistic', 'skincare minimal'],
  sports: ['stadium night lights', 'athlete silhouette', 'sports action', 'gym equipment'],
  music: ['concert lights', 'music studio neon', 'vinyl record', 'headphones aesthetic'],
  photography: ['camera lens', 'dark room photography', 'camera bokeh', 'photography minimal'],
  consulting: ['business meeting', 'corporate office minimal', 'handshake deal', 'strategy board'],
  retail: ['shopping luxury', 'retail store minimal', 'product display', 'ecommerce flat'],
  restaurant: ['coffee art latte', 'restaurant ambiance', 'cafe interior', 'food presentation'],
  crypto: ['bitcoin golden', 'blockchain network', 'crypto trading', 'digital currency'],
  agency: ['creative studio', 'design workspace', 'artistic colorful', 'creative team'],
  youtube: ['youtube creator setup', 'video production', 'content creator', 'streaming neon'],
  startup: ['startup office', 'innovation technology', 'entrepreneur', 'startup culture'],
  fitness: ['gym workout', 'fitness motivation', 'bodybuilding dark', 'running athlete'],
  podcast: ['podcast microphone', 'radio studio', 'sound waves', 'audio equipment'],
};

function getUnsplashImages(industry: string, businessName: string): NicheImage[] {
  const queries = NICHE_PHOTO_QUERIES[industry] || ['abstract minimal dark', 'professional brand', 'modern design'];
  return queries.slice(0, 4).map((q, i) => ({
    id: `img-${i}`,
    url: `https://source.unsplash.com/800x600/?${encodeURIComponent(q)}`,
    description: q,
    photographer: 'Unsplash',
  }));
}

function getPalette(config: LogoConfig): string[] {
  const palette = COLOR_PALETTES.find(p => p.id === config.colorPalette);
  return palette?.colors || ['#6366f1', '#8b5cf6', '#06b6d4', '#fff'];
}

// Deterministic hash for business name
function nameHash(name: string): number {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 1e9;
  return h;
}

function initials(name: string): string {
  const words = name.trim().split(/\s+/);
  if (words.length === 1) return name.substring(0, 2).toUpperCase();
  return (words[0][0] + words[words.length - 1][0]).toUpperCase();
}

// --- SVG Logo Generators by Style ---

function generateMinimalSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="200" fill="#08080e" rx="16"/>
  <rect x="40" y="60" width="80" height="80" fill="url(#g1)" rx="20" opacity="0.9"/>
  <text x="80" y="112" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="28" fill="white" text-anchor="middle" dominant-baseline="middle">${init}</text>
  <text x="200" y="90" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="26" fill="${c3}" letter-spacing="2">${config.businessName.toUpperCase()}</text>
  ${config.tagline ? `<text x="200" y="118" font-family="'DM Sans', sans-serif" font-weight="400" font-size="11" fill="rgba(255,255,255,0.5)" letter-spacing="3">${config.tagline.toUpperCase()}</text>` : ''}
  <line x1="160" y1="104" x2="360" y2="104" stroke="rgba(255,255,255,0.1)" stroke-width="0.5"/>
</svg>`;
}

function generateGradientSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3, c4] = colors;
  const init = initials(config.businessName);
  const h = nameHash(config.businessName);
  const shape = h % 3;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="50%" stop-color="${c2}"/>
      <stop offset="100%" stop-color="${c3}"/>
    </linearGradient>
    <linearGradient id="textGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="${c2}"/>
      <stop offset="100%" stop-color="${c3}"/>
    </linearGradient>
    <filter id="glow">
      <feGaussianBlur stdDeviation="4" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  </defs>
  <rect width="400" height="200" fill="#0a0a12" rx="16"/>
  ${shape === 0
    ? `<circle cx="80" cy="100" r="45" fill="url(#grad)" filter="url(#glow)" opacity="0.9"/>`
    : shape === 1
    ? `<rect x="35" y="55" width="90" height="90" fill="url(#grad)" filter="url(#glow)" rx="24" opacity="0.9"/>`
    : `<polygon points="80,58 125,100 80,142 35,100" fill="url(#grad)" filter="url(#glow)" opacity="0.9"/>`}
  <text x="80" y="107" font-family="'Space Grotesk', sans-serif" font-weight="800" font-size="30" fill="white" text-anchor="middle" dominant-baseline="middle" filter="url(#glow)">${init}</text>
  <text x="190" y="88" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="28" fill="url(#textGrad)" text-anchor="start">${config.businessName}</text>
  ${config.tagline ? `<text x="190" y="116" font-family="'DM Sans', sans-serif" font-size="12" fill="rgba(255,255,255,0.45)" letter-spacing="2">${config.tagline}</text>` : ''}
</svg>`;
}

function generateGeometricSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="geo-g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="200" fill="#09090f" rx="16"/>
  <!-- Geometric shapes -->
  <polygon points="80,55 125,78 125,122 80,145 35,122 35,78" fill="url(#geo-g)" opacity="0.85"/>
  <polygon points="80,65 115,85 115,115 80,135 45,115 45,85" fill="none" stroke="${c3}" stroke-width="1" opacity="0.4"/>
  <text x="80" y="107" font-family="'Space Grotesk', sans-serif" font-weight="800" font-size="26" fill="white" text-anchor="middle" dominant-baseline="middle">${init}</text>
  <text x="160" y="92" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="24" fill="white" letter-spacing="1">${config.businessName}</text>
  ${config.tagline ? `<text x="160" y="116" font-family="'DM Sans', sans-serif" font-size="11" fill="${c3}" letter-spacing="3">${config.tagline.toUpperCase()}</text>` : ''}
  <line x1="155" y1="102" x2="365" y2="102" stroke="${c2}" stroke-width="0.5" opacity="0.3"/>
</svg>`;
}

function generateNeonSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <filter id="neon-glow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="6" result="blur1"/>
      <feGaussianBlur stdDeviation="12" result="blur2"/>
      <feMerge><feMergeNode in="blur2"/><feMergeNode in="blur1"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id="text-glow">
      <feGaussianBlur stdDeviation="3" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
  <rect width="400" height="200" fill="#000008" rx="16"/>
  <!-- Grid lines -->
  <line x1="0" y1="100" x2="400" y2="100" stroke="${c1}" stroke-width="0.3" opacity="0.2"/>
  <line x1="200" y1="0" x2="200" y2="200" stroke="${c1}" stroke-width="0.3" opacity="0.2"/>
  <!-- Neon icon -->
  <circle cx="80" cy="100" r="40" fill="none" stroke="${c2}" stroke-width="2" filter="url(#neon-glow)" opacity="0.9"/>
  <circle cx="80" cy="100" r="30" fill="none" stroke="${c3}" stroke-width="1" filter="url(#neon-glow)" opacity="0.6"/>
  <text x="80" y="107" font-family="'Space Grotesk', sans-serif" font-weight="800" font-size="24" fill="${c2}" text-anchor="middle" dominant-baseline="middle" filter="url(#neon-glow)">${init}</text>
  <!-- Neon text -->
  <text x="190" y="95" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="28" fill="${c2}" filter="url(#text-glow)">${config.businessName.toUpperCase()}</text>
  ${config.tagline ? `<text x="190" y="120" font-family="'DM Sans', sans-serif" font-size="11" fill="${c3}" filter="url(#text-glow)" letter-spacing="4">${config.tagline.toUpperCase()}</text>` : ''}
</svg>`;
}

function generateMonogramSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="mono-g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="200" fill="#0c0c15" rx="16"/>
  <!-- Decorative rings -->
  <circle cx="200" cy="100" r="85" fill="none" stroke="${c1}" stroke-width="0.5" opacity="0.15"/>
  <circle cx="200" cy="100" r="70" fill="none" stroke="${c2}" stroke-width="0.5" opacity="0.2"/>
  <!-- Monogram mark -->
  <circle cx="200" cy="100" r="55" fill="url(#mono-g)" opacity="0.9"/>
  <text x="200" y="118" font-family="'Space Grotesk', sans-serif" font-weight="800" font-size="48" fill="white" text-anchor="middle" dominant-baseline="middle">${init}</text>
  <!-- Name below -->
  <text x="200" y="172" font-family="'Space Grotesk', sans-serif" font-weight="600" font-size="14" fill="${c3}" text-anchor="middle" letter-spacing="6">${config.businessName.toUpperCase()}</text>
  ${config.tagline ? `<text x="200" y="188" font-family="'DM Sans', sans-serif" font-size="9" fill="rgba(255,255,255,0.35)" text-anchor="middle" letter-spacing="3">${config.tagline.toUpperCase()}</text>` : ''}
</svg>`;
}

function generateBadgeSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="badge-g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="200" fill="#0a0a10" rx="16"/>
  <!-- Badge shape -->
  <polygon points="200,20 235,40 260,20 260,75 285,95 260,115 260,170 235,150 200,170 165,150 140,170 140,115 115,95 140,75 140,20 165,40" fill="url(#badge-g)" opacity="0.85"/>
  <polygon points="200,35 228,52 248,35 248,80 268,95 248,110 248,155 228,138 200,155 172,138 152,155 152,110 132,95 152,80 152,35 172,52" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>
  <!-- Text -->
  <text x="200" y="88" font-family="'Space Grotesk', sans-serif" font-weight="800" font-size="22" fill="white" text-anchor="middle" dominant-baseline="middle">${init}</text>
  <line x1="150" y1="100" x2="250" y2="100" stroke="rgba(255,255,255,0.3)" stroke-width="0.5"/>
  <text x="200" y="115" font-family="'Space Grotesk', sans-serif" font-size="9" font-weight="600" fill="${c3}" text-anchor="middle" letter-spacing="3">${config.businessName.toUpperCase().substring(0, 10)}</text>
</svg>`;
}

function generateLuxurySVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="lux-g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c3}"/>
      <stop offset="50%" stop-color="${c2}"/>
      <stop offset="100%" stop-color="${c3}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="200" fill="#060609" rx="16"/>
  <!-- Luxury decorative lines -->
  <line x1="40" y1="60" x2="180" y2="60" stroke="${c3}" stroke-width="0.5" opacity="0.4"/>
  <line x1="40" y1="140" x2="180" y2="140" stroke="${c3}" stroke-width="0.5" opacity="0.4"/>
  <!-- Diamond ornament -->
  <polygon points="110,65 130,100 110,135 90,100" fill="none" stroke="url(#lux-g)" stroke-width="1.5"/>
  <polygon points="110,75 120,100 110,125 100,100" fill="${c1}" opacity="0.6"/>
  <!-- Brand name -->
  <text x="200" y="88" font-family="'Space Grotesk', sans-serif" font-weight="300" font-size="28" fill="url(#lux-g)" text-anchor="middle" letter-spacing="8">${config.businessName.toUpperCase()}</text>
  <line x1="120" y1="100" x2="280" y2="100" stroke="${c3}" stroke-width="0.5" opacity="0.5"/>
  ${config.tagline
    ? `<text x="200" y="116" font-family="'DM Sans', sans-serif" font-size="10" fill="${c3}" text-anchor="middle" letter-spacing="5" opacity="0.7">${config.tagline.toUpperCase()}</text>`
    : `<text x="200" y="116" font-family="'DM Sans', sans-serif" font-size="10" fill="${c3}" text-anchor="middle" letter-spacing="5" opacity="0.5">EST. ${new Date().getFullYear()}</text>`}
</svg>`;
}

function generateFuturisticSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="fut-g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
    <clipPath id="hex-clip">
      <polygon points="80,58 115,78 115,118 80,138 45,118 45,78"/>
    </clipPath>
  </defs>
  <rect width="400" height="200" fill="#05050d" rx="16"/>
  <!-- Scan lines -->
  <line x1="0" y1="50" x2="400" y2="50" stroke="${c1}" stroke-width="0.3" opacity="0.1"/>
  <line x1="0" y1="100" x2="400" y2="100" stroke="${c1}" stroke-width="0.3" opacity="0.1"/>
  <line x1="0" y1="150" x2="400" y2="150" stroke="${c1}" stroke-width="0.3" opacity="0.1"/>
  <!-- Hexagon icon -->
  <polygon points="80,58 115,78 115,118 80,138 45,118 45,78" fill="url(#fut-g)" opacity="0.85"/>
  <polygon points="80,65 108,82 108,115 80,132 52,115 52,82" fill="none" stroke="${c3}" stroke-width="0.8" opacity="0.5"/>
  <text x="80" y="105" font-family="'Space Grotesk', sans-serif" font-weight="800" font-size="26" fill="white" text-anchor="middle" dominant-baseline="middle">${init}</text>
  <!-- Corner accents -->
  <line x1="155" y1="68" x2="175" y2="68" stroke="${c3}" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="155" y1="68" x2="155" y2="80" stroke="${c3}" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="360" y1="130" x2="340" y2="130" stroke="${c3}" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="360" y1="130" x2="360" y2="118" stroke="${c3}" stroke-width="1.5" stroke-linecap="round"/>
  <text x="175" y="96" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="26" fill="white" letter-spacing="2">${config.businessName}</text>
  ${config.tagline ? `<text x="175" y="120" font-family="'JetBrains Mono', monospace" font-size="10" fill="${c3}" letter-spacing="3">&gt; ${config.tagline}</text>` : ''}
</svg>`;
}

function generateVintageSVG(config: LogoConfig, colors: string[]): string {
  const [c1, c2, c3] = colors;
  const init = initials(config.businessName);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">
  <defs>
    <linearGradient id="vint-g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="400" height="200" fill="#0d0a06" rx="16"/>
  <!-- Vintage border -->
  <rect x="20" y="15" width="360" height="170" fill="none" stroke="${c3}" stroke-width="1" rx="4" opacity="0.3"/>
  <rect x="26" y="21" width="348" height="158" fill="none" stroke="${c3}" stroke-width="0.5" rx="2" opacity="0.2"/>
  <!-- Decorative crown/ornament -->
  <path d="M 200 45 L 215 55 L 200 50 L 185 55 Z" fill="${c3}" opacity="0.8"/>
  <circle cx="200" cy="42" r="4" fill="${c3}" opacity="0.8"/>
  <circle cx="186" cy="57" r="3" fill="${c3}" opacity="0.6"/>
  <circle cx="214" cy="57" r="3" fill="${c3}" opacity="0.6"/>
  <!-- Monogram -->
  <text x="200" y="110" font-family="'Space Grotesk', sans-serif" font-weight="700" font-size="42" fill="url(#vint-g)" text-anchor="middle" dominant-baseline="middle">${init}</text>
  <!-- Name -->
  <line x1="60" y1="140" x2="340" y2="140" stroke="${c3}" stroke-width="0.5" opacity="0.4"/>
  <text x="200" y="156" font-family="'Space Grotesk', sans-serif" font-weight="600" font-size="13" fill="${c3}" text-anchor="middle" letter-spacing="5" opacity="0.9">${config.businessName.toUpperCase()}</text>
  ${config.tagline ? `<text x="200" y="172" font-family="'DM Sans', sans-serif" font-size="9" fill="${c3}" text-anchor="middle" letter-spacing="3" opacity="0.5">${config.tagline.toUpperCase()}</text>` : ''}
</svg>`;
}

const STYLE_GENERATORS: Record<string, (c: LogoConfig, colors: string[]) => string> = {
  minimal: generateMinimalSVG,
  gradient: generateGradientSVG,
  geometric: generateGeometricSVG,
  neon: generateNeonSVG,
  monogram: generateMonogramSVG,
  badge: generateBadgeSVG,
  luxury: generateLuxurySVG,
  futuristic: generateFuturisticSVG,
  vintage: generateVintageSVG,
  tech: generateFuturisticSVG,
  startup: generateGradientSVG,
  gaming: generateNeonSVG,
  fashion: generateLuxurySVG,
  corporate: generateMinimalSVG,
  modern: generateGeometricSVG,
  elegant: generateLuxurySVG,
  abstract: generateGradientSVG,
  wordmark: generateMinimalSVG,
  lettermark: generateMonogramSVG,
  '3d': generateGeometricSVG,
  flat: generateMinimalSVG,
  mascot: generateBadgeSVG,
  handcrafted: generateVintageSVG,
};

export function generateLogoSVG(config: LogoConfig, styleOverride?: string): string {
  const colors = getPalette(config);
  const style = styleOverride || config.style;
  const generator = STYLE_GENERATORS[style] || generateGradientSVG;
  return generator(config, colors);
}

export function svgToDataURL(svg: string): string {
  const encoded = encodeURIComponent(svg).replace(/'/g, '%27').replace(/"/g, '%22');
  return `data:image/svg+xml;charset=utf-8,${encoded}`;
}

export async function generateMultipleLogos(config: LogoConfig): Promise<GeneratedLogo[]> {
  const styles = getStylesForConfig(config);
  const niche_images = getUnsplashImages(config.industry, config.businessName);

  return styles.map((style, i) => {
    const svg = generateLogoSVG(config, style);
    const imageUrl = svgToDataURL(svg);
    return {
      id: `logo-${Date.now()}-${i}`,
      imageUrl,
      svgCode: svg,
      prompt: buildPrompt(config, style),
      style: style as any,
      config,
      createdAt: new Date(),
      isFavorite: false,
      niche_images,
      variants: generateVariants(config, style),
    };
  });
}

function getStylesForConfig(config: LogoConfig): string[] {
  const primary = config.style;
  const industryExtras: Record<string, string[]> = {
    technology: ['futuristic', 'geometric', 'neon', 'minimal'],
    gaming: ['neon', 'futuristic', 'badge', 'geometric'],
    fashion: ['luxury', 'minimal', 'elegant', 'vintage'],
    food: ['vintage', 'badge', 'minimal', 'gradient'],
    finance: ['minimal', 'geometric', 'luxury', 'corporate'],
    beauty: ['luxury', 'minimal', 'elegant', 'gradient'],
    startup: ['gradient', 'minimal', 'geometric', 'futuristic'],
    restaurant: ['vintage', 'badge', 'luxury', 'minimal'],
  };
  const extras = industryExtras[config.industry] || ['gradient', 'geometric', 'minimal', 'badge'];
  const all = [primary, ...extras.filter(s => s !== primary)].slice(0, 6);
  return all;
}

function generateVariants(config: LogoConfig, style: string): any[] {
  const colors = getPalette(config);
  const init = initials(config.businessName);
  return [
    {
      id: `v-icon`,
      type: 'icon-only',
      imageUrl: svgToDataURL(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
        <defs><linearGradient id="vg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="${colors[0]}"/><stop offset="100%" stop-color="${colors[1]}"/></linearGradient></defs>
        <rect width="100" height="100" fill="#0a0a0f" rx="24"/>
        <circle cx="50" cy="50" r="35" fill="url(#vg)"/>
        <text x="50" y="62" font-family="'Space Grotesk',sans-serif" font-weight="800" font-size="28" fill="white" text-anchor="middle">${init}</text>
      </svg>`),
    },
    {
      id: `v-horizontal`,
      type: 'horizontal',
      imageUrl: svgToDataURL(generateLogoSVG(config, style)),
    },
  ];
}

function buildPrompt(config: LogoConfig, style: string): string {
  const paletteInfo = COLOR_PALETTES.find(p => p.id === config.colorPalette);
  return `${style} logo for "${config.businessName}" ${config.industry} brand. Colors: ${paletteInfo?.name || config.colorPalette}. ${config.tagline ? `Tagline: "${config.tagline}".` : ''} Professional branding design.`;
}

export function downloadSVG(svg: string, filename: string): void {
  const blob = new Blob([svg], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.svg`;
  a.click();
  URL.revokeObjectURL(url);
}

export function downloadPNG(dataUrl: string, filename: string): void {
  const img = new Image();
  img.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 600;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(img, 0, 0, 1200, 600);
    canvas.toBlob(blob => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.png`;
      a.click();
      URL.revokeObjectURL(url);
    }, 'image/png');
  };
  img.src = dataUrl;
}
