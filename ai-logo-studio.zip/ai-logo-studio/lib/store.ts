import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { LogoConfig, GeneratedLogo } from '@/types';

interface LogoStore {
  config: LogoConfig;
  logos: GeneratedLogo[];
  selectedLogo: GeneratedLogo | null;
  isGenerating: boolean;
  history: GeneratedLogo[];
  favorites: string[];

  setConfig: (partial: Partial<LogoConfig>) => void;
  setLogos: (logos: GeneratedLogo[]) => void;
  selectLogo: (logo: GeneratedLogo | null) => void;
  setGenerating: (v: boolean) => void;
  addToHistory: (logos: GeneratedLogo[]) => void;
  toggleFavorite: (id: string) => void;
  clearHistory: () => void;
}

const defaultConfig: LogoConfig = {
  businessName: '',
  tagline: '',
  industry: 'startup',
  style: 'gradient',
  colorPalette: 'midnight',
  creativity: 70,
  detailLevel: 'moderate',
  mood: 'professional',
};

export const useLogoStore = create<LogoStore>()(
  persist(
    (set, get) => ({
      config: defaultConfig,
      logos: [],
      selectedLogo: null,
      isGenerating: false,
      history: [],
      favorites: [],

      setConfig: (partial) =>
        set((s) => ({ config: { ...s.config, ...partial } })),

      setLogos: (logos) => set({ logos }),

      selectLogo: (logo) => set({ selectedLogo: logo }),

      setGenerating: (v) => set({ isGenerating: v }),

      addToHistory: (logos) =>
        set((s) => ({ history: [...logos, ...s.history].slice(0, 50) })),

      toggleFavorite: (id) =>
        set((s) => ({
          favorites: s.favorites.includes(id)
            ? s.favorites.filter((f) => f !== id)
            : [...s.favorites, id],
          logos: s.logos.map((l) =>
            l.id === id ? { ...l, isFavorite: !l.isFavorite } : l
          ),
        })),

      clearHistory: () => set({ history: [] }),
    }),
    { name: 'logostudio-store', partialize: (s) => ({ history: s.history, favorites: s.favorites }) }
  )
);
