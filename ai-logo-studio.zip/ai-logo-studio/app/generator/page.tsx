'use client';
import { useState, useCallback } from 'react';
import Link from 'next/link';
import {
  Sparkles, Wand2, Download, Heart, RefreshCw, ZoomIn, Image,
  Palette, Type, Sliders, ChevronRight, Copy, Share2, Trash2,
  ArrowLeft, Eye, Package, Star, ExternalLink, Grid3X3
} from 'lucide-react';
import { useLogoStore } from '@/lib/store';
import { generateMultipleLogos, downloadSVG, downloadPNG } from '@/lib/logo-generator';
import { LOGO_STYLES, INDUSTRIES, COLOR_PALETTES, type LogoStyle, type Industry, type ColorPalette, type GeneratedLogo } from '@/types';

const FONT_OPTIONS = ['Space Grotesk', 'DM Sans', 'Playfair Display', 'Bebas Neue', 'Pacifico', 'Montserrat', 'Raleway', 'Oswald'];
const MOOD_OPTIONS = ['professional', 'playful', 'bold', 'elegant', 'friendly', 'serious'] as const;

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 whitespace-nowrap
        ${active ? 'bg-brand-500 text-white shadow-glow-sm' : 'text-text-secondary hover:text-white hover:bg-white/5'}`}
    >
      {children}
    </button>
  );
}

function StyleCard({ style, selected, onClick }: { style: typeof LOGO_STYLES[0]; selected: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`p-3 rounded-xl border text-left transition-all duration-200 ${
        selected
          ? 'bg-brand-500/15 border-brand-500/60 shadow-glow-sm'
          : 'bg-surface-2 border-white/5 hover:border-white/15 hover:bg-surface-3'
      }`}
    >
      <div className="text-2xl mb-1">{style.icon}</div>
      <div className={`text-xs font-semibold ${selected ? 'text-brand-400' : 'text-white'}`}>{style.name}</div>
      <div className="text-text-muted text-xs mt-0.5 leading-tight">{style.description}</div>
    </button>
  );
}

function ColorCard({ palette, selected, onClick }: { palette: typeof COLOR_PALETTES[0]; selected: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`p-3 rounded-xl border text-left transition-all duration-200 ${
        selected ? 'border-brand-500/60 shadow-glow-sm' : 'border-white/5 hover:border-white/15'
      }`}
      style={{ background: selected ? `${palette.colors[0]}40` : 'rgba(255,255,255,0.02)' }}
    >
      <div className="flex gap-1 mb-2">
        {palette.colors.slice(0, 4).map((c, i) => (
          <div key={i} className="flex-1 h-4 rounded" style={{ backgroundColor: c }} />
        ))}
      </div>
      <div className={`text-xs font-medium ${selected ? 'text-white' : 'text-text-secondary'}`}>{palette.name}</div>
    </button>
  );
}

function LogoCard({ logo, selected, onSelect, onFavorite, onDownload }: {
  logo: GeneratedLogo;
  selected: boolean;
  onSelect: () => void;
  onFavorite: () => void;
  onDownload: () => void;
}) {
  return (
    <div
      className={`card group cursor-pointer relative overflow-hidden transition-all duration-300 ${
        selected ? 'border-brand-500/60 shadow-glow' : 'hover:border-brand-500/30'
      }`}
      onClick={onSelect}
    >
      <div className="aspect-video bg-surface-2 rounded-t-xl overflow-hidden relative">
        <img src={logo.imageUrl} alt={logo.config.businessName} className="w-full h-full object-contain p-2" />
        {selected && (
          <div className="absolute inset-0 border-2 border-brand-500/60 rounded-t-xl pointer-events-none" />
        )}
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
          <button
            onClick={(e) => { e.stopPropagation(); onFavorite(); }}
            className={`w-7 h-7 rounded-lg glass flex items-center justify-center transition-all ${logo.isFavorite ? 'text-rose-400' : 'text-white/60 hover:text-rose-400'}`}
          >
            <Heart className={`w-3.5 h-3.5 ${logo.isFavorite ? 'fill-current' : ''}`} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); onDownload(); }}
            className="w-7 h-7 rounded-lg glass flex items-center justify-center text-white/60 hover:text-white transition-all"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-sm rounded-md px-2 py-0.5">
          <span className="text-xs text-white/70 capitalize">{logo.style}</span>
        </div>
      </div>
      <div className="p-3">
        <div className="text-white text-sm font-medium">{logo.config.businessName}</div>
        <div className="text-text-muted text-xs mt-0.5">{logo.config.industry}</div>
      </div>
    </div>
  );
}

function SkeletonCard() {
  return (
    <div className="card overflow-hidden">
      <div className="aspect-video bg-surface-2 rounded-t-xl shimmer-bg" />
      <div className="p-3 space-y-2">
        <div className="h-4 bg-surface-3 rounded shimmer-bg w-3/4" />
        <div className="h-3 bg-surface-3 rounded shimmer-bg w-1/2" />
      </div>
    </div>
  );
}

function NicheImageCard({ url, description }: { url: string; description: string }) {
  return (
    <div className="relative rounded-xl overflow-hidden aspect-video group">
      <img
        src={url}
        alt={description}
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        onError={(e) => { (e.target as HTMLImageElement).src = `https://picsum.photos/seed/${Math.random()}/800/600`; }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
      <div className="absolute bottom-2 left-3 text-white text-xs capitalize">{description}</div>
    </div>
  );
}

export default function GeneratorPage() {
  const { config, logos, selectedLogo, isGenerating, favorites } = useLogoStore();
  const { setConfig, setLogos, selectLogo, setGenerating, addToHistory, toggleFavorite } = useLogoStore();

  const [activeTab, setActiveTab] = useState<'config' | 'results' | 'mockups' | 'niche'>('config');
  const [configTab, setConfigTab] = useState<'basic' | 'style' | 'colors' | 'advanced'>('basic');
  const [error, setError] = useState('');

  const handleGenerate = useCallback(async () => {
    if (!config.businessName.trim()) {
      setError('Please enter your business name to continue.');
      return;
    }
    setError('');
    setGenerating(true);
    setActiveTab('results');

    try {
      const generated = await generateMultipleLogos(config);
      setLogos(generated);
      addToHistory(generated);
      if (generated.length > 0) selectLogo(generated[0]);
    } catch (e: any) {
      setError(e.message || 'Generation failed. Please try again.');
    } finally {
      setGenerating(false);
    }
  }, [config]);

  const handleDownloadSVG = (logo: GeneratedLogo) => {
    if (logo.svgCode) downloadSVG(logo.svgCode, logo.config.businessName);
  };

  const handleDownloadPNG = (logo: GeneratedLogo) => {
    downloadPNG(logo.imageUrl, logo.config.businessName);
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Top bar */}
      <header className="glass-strong border-b border-white/5 h-14 flex items-center px-6 gap-4 sticky top-0 z-50">
        <Link href="/" className="flex items-center gap-2 text-text-secondary hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm">Back</span>
        </Link>
        <div className="w-px h-5 bg-white/10" />
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-brand-500 to-accent-violet flex items-center justify-center">
            <Sparkles className="w-3 h-3 text-white" />
          </div>
          <span className="font-display font-bold text-white text-sm">LogoStudio AI</span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {logos.length > 0 && (
            <>
              <span className="text-text-muted text-xs">{logos.length} logos generated</span>
              <div className="w-px h-5 bg-white/10" />
            </>
          )}
          <Link href="/auth/login" className="text-text-secondary hover:text-white text-sm transition-colors">Sign In</Link>
          <button className="btn-primary text-xs py-2 px-4">Save Project</button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* LEFT PANEL - Config */}
        <aside className="w-80 bg-surface-1 border-r border-white/5 flex flex-col overflow-y-auto shrink-0">
          {/* Config tabs */}
          <div className="p-4 border-b border-white/5">
            <div className="flex gap-1 bg-surface-2 p-1 rounded-xl">
              {(['basic', 'style', 'colors', 'advanced'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setConfigTab(tab)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all capitalize ${
                    configTab === tab ? 'bg-brand-500 text-white' : 'text-text-muted hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 p-4 space-y-5 overflow-y-auto">
            {configTab === 'basic' && (
              <>
                <div>
                  <label className="label">Business Name *</label>
                  <input
                    type="text"
                    value={config.businessName}
                    onChange={e => setConfig({ businessName: e.target.value })}
                    placeholder="e.g. NovaTech, Bloom, GigaPlay"
                    className="input-field"
                    maxLength={30}
                  />
                  {error && <p className="text-rose-400 text-xs mt-1.5">{error}</p>}
                </div>

                <div>
                  <label className="label">Tagline <span className="text-text-muted normal-case font-normal">(optional)</span></label>
                  <input
                    type="text"
                    value={config.tagline || ''}
                    onChange={e => setConfig({ tagline: e.target.value })}
                    placeholder="e.g. Beyond Innovation"
                    className="input-field"
                    maxLength={40}
                  />
                </div>

                <div>
                  <label className="label">Industry / Niche</label>
                  <div className="grid grid-cols-2 gap-1.5 max-h-52 overflow-y-auto pr-1">
                    {INDUSTRIES.map(ind => (
                      <button
                        key={ind.id}
                        onClick={() => setConfig({ industry: ind.id })}
                        className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-medium text-left transition-all ${
                          config.industry === ind.id
                            ? 'bg-brand-500/20 border border-brand-500/40 text-white'
                            : 'bg-surface-2 border border-transparent text-text-secondary hover:text-white hover:bg-surface-3'
                        }`}
                      >
                        <span>{ind.icon}</span>
                        <span className="truncate">{ind.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="label">Brand Mood</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {MOOD_OPTIONS.map(mood => (
                      <button
                        key={mood}
                        onClick={() => setConfig({ mood })}
                        className={`py-2 rounded-lg text-xs font-medium capitalize transition-all ${
                          config.mood === mood
                            ? 'bg-brand-500/20 border border-brand-500/40 text-brand-300'
                            : 'bg-surface-2 border border-transparent text-text-muted hover:text-white'
                        }`}
                      >
                        {mood}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            {configTab === 'style' && (
              <div>
                <label className="label">Logo Style</label>
                <div className="grid grid-cols-2 gap-2">
                  {LOGO_STYLES.map(style => (
                    <StyleCard
                      key={style.id}
                      style={style}
                      selected={config.style === style.id}
                      onClick={() => setConfig({ style: style.id as LogoStyle })}
                    />
                  ))}
                </div>
              </div>
            )}

            {configTab === 'colors' && (
              <>
                <div>
                  <label className="label">Color Palette</label>
                  <div className="grid grid-cols-2 gap-2">
                    {COLOR_PALETTES.map(palette => (
                      <ColorCard
                        key={palette.id}
                        palette={palette}
                        selected={config.colorPalette === palette.id}
                        onClick={() => setConfig({ colorPalette: palette.id as ColorPalette })}
                      />
                    ))}
                  </div>
                </div>
              </>
            )}

            {configTab === 'advanced' && (
              <>
                <div>
                  <label className="label flex justify-between">
                    <span>AI Creativity</span>
                    <span className="text-brand-400 font-mono">{config.creativity}%</span>
                  </label>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    value={config.creativity}
                    onChange={e => setConfig({ creativity: +e.target.value })}
                    className="w-full mt-2"
                  />
                  <div className="flex justify-between text-text-muted text-xs mt-1">
                    <span>Conservative</span>
                    <span>Experimental</span>
                  </div>
                </div>

                <div>
                  <label className="label">Detail Level</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['minimal', 'moderate', 'detailed'] as const).map(d => (
                      <button
                        key={d}
                        onClick={() => setConfig({ detailLevel: d })}
                        className={`py-2.5 rounded-xl text-xs font-medium capitalize transition-all ${
                          config.detailLevel === d
                            ? 'bg-brand-500/20 border border-brand-500/40 text-brand-300'
                            : 'bg-surface-2 border border-transparent text-text-muted hover:text-white'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="label">Font Style</label>
                  <select
                    value={config.fontStyle || ''}
                    onChange={e => setConfig({ fontStyle: e.target.value })}
                    className="input-field"
                  >
                    <option value="">Auto Select</option>
                    {FONT_OPTIONS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>

                <div>
                  <label className="label">Icon Preference</label>
                  <input
                    type="text"
                    value={config.iconPreference || ''}
                    onChange={e => setConfig({ iconPreference: e.target.value })}
                    placeholder="e.g. lightning bolt, leaf, rocket..."
                    className="input-field"
                  />
                </div>
              </>
            )}
          </div>

          {/* Generate button */}
          <div className="p-4 border-t border-white/5">
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !config.businessName.trim()}
              className="w-full btn-primary py-4 flex items-center justify-center gap-2 text-base disabled:opacity-50 disabled:cursor-not-allowed glow-border"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5" />
                  Generate Logos
                </>
              )}
            </button>
            <p className="text-text-muted text-xs text-center mt-2">Generates 6+ unique concepts</p>
          </div>
        </aside>

        {/* MAIN CONTENT */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* View tabs */}
          <div className="border-b border-white/5 px-6 py-3 flex items-center gap-2 bg-surface-1/50">
            <TabButton active={activeTab === 'config'} onClick={() => setActiveTab('config')}>
              <span className="flex items-center gap-1.5"><Sliders className="w-3.5 h-3.5" /> Configure</span>
            </TabButton>
            <TabButton active={activeTab === 'results'} onClick={() => setActiveTab('results')}>
              <span className="flex items-center gap-1.5"><Grid3X3 className="w-3.5 h-3.5" /> Results {logos.length > 0 && `(${logos.length})`}</span>
            </TabButton>
            <TabButton active={activeTab === 'mockups'} onClick={() => setActiveTab('mockups')}>
              <span className="flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" /> Mockups</span>
            </TabButton>
            <TabButton active={activeTab === 'niche'} onClick={() => setActiveTab('niche')}>
              <span className="flex items-center gap-1.5"><Image className="w-3.5 h-3.5" /> Niche Images</span>
            </TabButton>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {/* CONFIG TAB */}
            {activeTab === 'config' && (
              <div className="max-w-2xl mx-auto text-center py-16">
                <div className="w-20 h-20 rounded-3xl bg-brand-500/10 border border-brand-500/20 flex items-center justify-center mx-auto mb-6">
                  <Wand2 className="w-10 h-10 text-brand-400" />
                </div>
                <h2 className="font-display font-bold text-3xl text-white mb-3">Configure Your Logo</h2>
                <p className="text-text-secondary mb-8 max-w-md mx-auto">
                  Fill in your brand details on the left panel, choose your style and colors, then hit Generate.
                </p>
                <div className="grid grid-cols-3 gap-4 mb-8">
                  {[['1', 'Enter Details', 'Business name & industry'], ['2', 'Pick Style', 'Choose from 24+ styles'], ['3', 'Generate', '6+ concepts in seconds']].map(([num, title, desc]) => (
                    <div key={num} className="card p-4 text-center">
                      <div className="w-8 h-8 rounded-full bg-brand-500/20 border border-brand-500/30 flex items-center justify-center mx-auto mb-3 text-brand-400 text-sm font-bold">{num}</div>
                      <div className="text-white text-sm font-medium mb-1">{title}</div>
                      <div className="text-text-muted text-xs">{desc}</div>
                    </div>
                  ))}
                </div>
                <button
                  onClick={handleGenerate}
                  disabled={!config.businessName.trim()}
                  className="btn-primary py-4 px-10 text-base flex items-center gap-2 mx-auto disabled:opacity-40"
                >
                  <Sparkles className="w-5 h-5" />
                  {config.businessName ? `Generate for "${config.businessName}"` : 'Enter a business name first'}
                </button>
              </div>
            )}

            {/* RESULTS TAB */}
            {activeTab === 'results' && (
              <div>
                {isGenerating ? (
                  <>
                    <div className="flex items-center gap-3 mb-6">
                      <RefreshCw className="w-5 h-5 text-brand-400 animate-spin" />
                      <span className="text-white font-medium">Generating your logos...</span>
                      <span className="text-text-muted text-sm">This takes ~2 seconds</span>
                    </div>
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                      {Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)}
                    </div>
                  </>
                ) : logos.length > 0 ? (
                  <>
                    <div className="flex items-center justify-between mb-5">
                      <div>
                        <h2 className="text-white font-display font-bold text-xl">{logos[0].config.businessName} Logos</h2>
                        <p className="text-text-muted text-sm">{logos.length} concepts generated</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={handleGenerate} className="btn-secondary text-sm py-2 px-4 flex items-center gap-2">
                          <RefreshCw className="w-3.5 h-3.5" />
                          Regenerate
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                      {logos.map(logo => (
                        <LogoCard
                          key={logo.id}
                          logo={logo}
                          selected={selectedLogo?.id === logo.id}
                          onSelect={() => selectLogo(logo)}
                          onFavorite={() => toggleFavorite(logo.id)}
                          onDownload={() => handleDownloadPNG(logo)}
                        />
                      ))}
                    </div>

                    {selectedLogo && (
                      <div className="mt-6 card p-5">
                        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                          <Star className="w-4 h-4 text-brand-400" />
                          Selected Logo — Export Options
                        </h3>
                        <div className="flex flex-wrap gap-3">
                          <button
                            onClick={() => handleDownloadPNG(selectedLogo)}
                            className="btn-primary text-sm py-2.5 px-5 flex items-center gap-2"
                          >
                            <Download className="w-4 h-4" />
                            Download PNG
                          </button>
                          <button
                            onClick={() => handleDownloadSVG(selectedLogo)}
                            className="btn-secondary text-sm py-2.5 px-5 flex items-center gap-2"
                          >
                            <Download className="w-4 h-4" />
                            Download SVG
                          </button>
                          <button
                            onClick={() => toggleFavorite(selectedLogo.id)}
                            className={`btn-secondary text-sm py-2.5 px-5 flex items-center gap-2 ${selectedLogo.isFavorite ? 'text-rose-400 border-rose-400/30' : ''}`}
                          >
                            <Heart className={`w-4 h-4 ${selectedLogo.isFavorite ? 'fill-current' : ''}`} />
                            {selectedLogo.isFavorite ? 'Favorited' : 'Favorite'}
                          </button>
                          <button className="btn-secondary text-sm py-2.5 px-5 flex items-center gap-2">
                            <Copy className="w-4 h-4" />
                            Copy SVG
                          </button>
                          <button className="btn-secondary text-sm py-2.5 px-5 flex items-center gap-2">
                            <Share2 className="w-4 h-4" />
                            Share
                          </button>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-20">
                    <div className="w-16 h-16 rounded-2xl bg-surface-2 border border-white/5 flex items-center justify-center mx-auto mb-4">
                      <Grid3X3 className="w-8 h-8 text-text-muted" />
                    </div>
                    <h3 className="text-white font-medium mb-2">No logos yet</h3>
                    <p className="text-text-muted text-sm">Configure your brand and click Generate</p>
                    <button onClick={() => setActiveTab('config')} className="btn-primary text-sm py-2.5 px-6 mt-4 flex items-center gap-2 mx-auto">
                      <Wand2 className="w-4 h-4" />
                      Get Started
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* MOCKUPS TAB */}
            {activeTab === 'mockups' && (
              <div>
                <h2 className="text-white font-display font-bold text-xl mb-2">Logo Mockups</h2>
                <p className="text-text-muted text-sm mb-6">See how your logo looks in real-world contexts</p>
                {selectedLogo ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {[
                      { name: 'Business Card', bg: '#1a1a2e', size: 'aspect-[1.75/1]' },
                      { name: 'App Icon', bg: '#0f0f18', size: 'aspect-square max-w-48' },
                      { name: 'Website Header', bg: '#080810', size: 'aspect-[4/1]' },
                      { name: 'T-Shirt', bg: '#111118', size: 'aspect-[3/4] max-w-sm' },
                    ].map(({ name, bg, size }) => (
                      <div key={name} className="card p-4">
                        <div className="text-white text-sm font-medium mb-3 flex items-center gap-2">
                          <Package className="w-4 h-4 text-brand-400" />
                          {name}
                        </div>
                        <div className={`${size} w-full rounded-xl flex items-center justify-center p-6 mx-auto`} style={{ backgroundColor: bg }}>
                          <img src={selectedLogo.imageUrl} alt={name} className="max-w-full max-h-full object-contain" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20">
                    <Eye className="w-12 h-12 text-text-muted mx-auto mb-3" />
                    <p className="text-text-muted">Generate and select a logo to see mockups</p>
                  </div>
                )}
              </div>
            )}

            {/* NICHE IMAGES TAB */}
            {activeTab === 'niche' && (
              <div>
                <h2 className="text-white font-display font-bold text-xl mb-1">Niche Inspiration</h2>
                <p className="text-text-muted text-sm mb-6">
                  Curated imagery for <span className="text-brand-400">{config.industry}</span> brands — use as inspiration for your visual identity
                </p>
                {logos[0]?.niche_images && logos[0].niche_images.length > 0 ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      {logos[0].niche_images.map(img => (
                        <NicheImageCard key={img.id} url={img.url} description={img.description} />
                      ))}
                    </div>
                    <div className="mt-5 card p-4 flex items-center gap-3">
                      <ExternalLink className="w-4 h-4 text-brand-400 shrink-0" />
                      <p className="text-text-secondary text-sm">
                        Images sourced from Unsplash for inspiration. For commercial use, download directly from{' '}
                        <a href="https://unsplash.com" target="_blank" rel="noopener noreferrer" className="text-brand-400 hover:underline">unsplash.com</a>
                      </p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-20">
                    <Image className="w-12 h-12 text-text-muted mx-auto mb-3" />
                    <p className="text-text-muted">Generate a logo first to see niche images</p>
                    <button onClick={handleGenerate} disabled={!config.businessName.trim()} className="btn-primary text-sm py-2.5 px-6 mt-4 flex items-center gap-2 mx-auto disabled:opacity-40">
                      <Wand2 className="w-4 h-4" />
                      Generate Now
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </main>

        {/* RIGHT PANEL - Selected logo detail */}
        {selectedLogo && (
          <aside className="w-64 bg-surface-1 border-l border-white/5 flex flex-col shrink-0 overflow-y-auto">
            <div className="p-4 border-b border-white/5">
              <h3 className="text-white text-sm font-semibold">Logo Details</h3>
            </div>
            <div className="p-4 space-y-4">
              <div className="bg-surface-2 rounded-xl p-4 flex items-center justify-center aspect-video">
                <img src={selectedLogo.imageUrl} alt={selectedLogo.config.businessName} className="w-full h-full object-contain" />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-text-muted">Name</span>
                  <span className="text-white">{selectedLogo.config.businessName}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-text-muted">Style</span>
                  <span className="text-white capitalize">{selectedLogo.style}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-text-muted">Industry</span>
                  <span className="text-white capitalize">{selectedLogo.config.industry}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-text-muted">Colors</span>
                  <span className="text-white capitalize">{selectedLogo.config.colorPalette}</span>
                </div>
              </div>

              {selectedLogo.variants && selectedLogo.variants.length > 0 && (
                <div>
                  <label className="label text-[10px]">Variants</label>
                  <div className="space-y-2">
                    {selectedLogo.variants.map(v => (
                      <div key={v.id} className="bg-surface-2 rounded-lg p-2 flex items-center gap-2">
                        <img src={v.imageUrl} alt={v.type} className="w-12 h-8 object-contain rounded" />
                        <span className="text-text-secondary text-xs capitalize">{v.type.replace('-', ' ')}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-2 pt-2">
                <button
                  onClick={() => handleDownloadPNG(selectedLogo)}
                  className="w-full btn-primary text-xs py-2.5 flex items-center justify-center gap-2"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download PNG
                </button>
                <button
                  onClick={() => handleDownloadSVG(selectedLogo)}
                  className="w-full btn-secondary text-xs py-2.5 flex items-center justify-center gap-2"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download SVG
                </button>
                <button
                  onClick={() => toggleFavorite(selectedLogo.id)}
                  className={`w-full btn-secondary text-xs py-2.5 flex items-center justify-center gap-2 ${selectedLogo.isFavorite ? 'text-rose-400' : ''}`}
                >
                  <Heart className={`w-3.5 h-3.5 ${selectedLogo.isFavorite ? 'fill-current' : ''}`} />
                  {selectedLogo.isFavorite ? 'Favorited' : 'Save Favorite'}
                </button>
              </div>
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
