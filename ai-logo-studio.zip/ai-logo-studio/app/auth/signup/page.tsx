'use client';
import Link from 'next/link';
import { useState } from 'react';
import { Sparkles, Mail, Lock, User, Eye, EyeOff, ArrowLeft, Check } from 'lucide-react';

const PERKS = ['6+ logo concepts per generation', 'All 24+ styles unlocked', 'PNG & SVG download', 'Niche inspiration images'];

export default function SignupPage() {
  const [showPw, setShowPw] = useState(false);
  return (
    <div className="min-h-screen bg-surface grid-bg flex items-center justify-center p-6">
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-accent-violet/8 blur-[100px] rounded-full pointer-events-none" />
      <div className="w-full max-w-sm relative">
        <Link href="/" className="flex items-center gap-2 text-text-muted hover:text-white transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm">Back to home</span>
        </Link>
        <div className="flex items-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-accent-violet flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="font-display font-bold text-white text-xl">LogoStudio AI</span>
        </div>

        <div className="card p-7">
          <h1 className="font-display font-bold text-white text-2xl mb-1">Create your account</h1>
          <p className="text-text-muted text-sm mb-4">Start generating professional logos for free</p>

          <div className="bg-brand-500/8 border border-brand-500/15 rounded-xl p-3 mb-5">
            <div className="grid grid-cols-2 gap-1.5">
              {PERKS.map(p => (
                <div key={p} className="flex items-center gap-1.5 text-xs text-brand-300">
                  <Check className="w-3 h-3 text-brand-400 shrink-0" />
                  {p}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="label">Full Name</label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
                <input type="text" placeholder="Alex Chen" className="input-field pl-10" />
              </div>
            </div>
            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
                <input type="email" placeholder="you@example.com" className="input-field pl-10" />
              </div>
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
                <input type={showPw ? 'text' : 'password'} placeholder="Min. 8 characters" className="input-field pl-10 pr-10" />
                <button type="button" onClick={() => setShowPw(v => !v)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-text-muted hover:text-white">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <Link href="/generator" className="btn-primary w-full py-3 flex items-center justify-center text-sm glow-border">
              Create Free Account
            </Link>
          </div>

          <p className="text-center text-text-muted text-xs mt-4 leading-relaxed">
            By signing up you agree to our{' '}
            <a href="#" className="text-brand-400">Terms</a> and{' '}
            <a href="#" className="text-brand-400">Privacy Policy</a>
          </p>

          <p className="text-center text-text-muted text-sm mt-3">
            Already have an account?{' '}
            <Link href="/auth/login" className="text-brand-400 hover:text-brand-300">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
