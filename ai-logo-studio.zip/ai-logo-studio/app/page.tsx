'use client';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Sparkles, Zap, Download, Palette, Shield, Star, ChevronRight, Play, Check, ArrowRight } from 'lucide-react';
import { generateLogoSVG, svgToDataURL } from '@/lib/logo-generator';
import { LOGO_STYLES, COLOR_PALETTES } from '@/types';

const DEMO_CONFIGS = [
  { businessName: 'NovaTech', tagline: 'Beyond Innovation', industry: 'technology' as any, style: 'futuristic' as any, colorPalette: 'midnight' as any, creativity: 80, detailLevel: 'moderate' as any },
  { businessName: 'Luxe', tagline: 'Premium Quality', industry: 'fashion' as any, style: 'luxury' as any, colorPalette: 'gold' as any, creativity: 70, detailLevel: 'moderate' as any },
  { businessName: 'GigaPlay', tagline: 'Level Up', industry: 'gaming' as any, style: 'neon' as any, colorPalette: 'neon' as any, creativity: 90, detailLevel: 'detailed' as any },
  { businessName: 'Bloom', tagline: 'Wellness First', industry: 'health' as any, style: 'gradient' as any, colorPalette: 'forest' as any, creativity: 75, detailLevel: 'moderate' as any },
  { businessName: 'Orbit', tagline: 'Going Places', industry: 'startup' as any, style: 'geometric' as any, colorPalette: 'cosmic' as any, creativity: 85, detailLevel: 'moderate' as any },
  { businessName: 'Verse', tagline: 'Your Story', industry: 'podcast' as any, style: 'minimal' as any, colorPalette: 'royal' as any, creativity: 65, detailLevel: 'minimal' as any },
];

const FEATURES = [
  { icon: Zap, title: 'AI-Powered Generation', desc: 'Advanced algorithms create unique logos tailored to your brand identity and industry.' },
  { icon: Palette, title: '24+ Style Variations', desc: 'From minimal to luxury, gaming to vintage — every style you need in one platform.' },
  { icon: Download, title: 'HD Export Ready', desc: 'Download in PNG, SVG, and more. Perfect for web, print, and everything in between.' },
  { icon: Shield, title: 'Commercial License', desc: 'All generated logos come with full commercial usage rights. Use them anywhere.' },
  { icon: Star, title: 'Niche-Specific Imagery', desc: 'Get curated inspiration images matched to your industry and brand aesthetic.' },
  { icon: Sparkles, title: 'Multiple Concepts', desc: 'Get 6+ unique logo concepts per generation — find the perfect match instantly.' },
];

const TESTIMONIALS = [
  { name: 'Alex Chen', role: 'Founder, NovaTech', text: 'Generated a stunning logo in under 2 minutes. The futuristic style was exactly what my tech startup needed.', rating: 5, avatar: 'AC' },
  { name: 'Maria Santos', role: 'Creative Director', text: 'As a designer, I use LogoStudio AI for rapid prototyping. The quality is genuinely impressive.', rating: 5, avatar: 'MS' },
  { name: 'Jordan Lee', role: 'YouTuber, 500K subs', text: 'My channel brand completely transformed. The gaming neon style was perfect for my content.', rating: 5, avatar: 'JL' },
  { name: 'Priya Patel', role: 'Restaurant Owner', text: 'The vintage badge style for my cafe was spot-on. Customers always compliment the branding.', rating: 5, avatar: 'PP' },
];

const PRICING = [
  { name: 'Free', price: 0, period: 'forever', features: ['5 logo generations/mo', '3 style options', 'PNG download', 'Watermarked output'], cta: 'Get Started', popular: false },
  { name: 'Pro', price: 19, period: 'month', features: ['Unlimited generations', 'All 24+ styles', 'SVG + PNG export', 'Background removal', 'No watermark', 'Commercial license', 'Niche inspiration images'], cta: 'Start Free Trial', popular: true },
  { name: 'Business', price: 49, period: 'month', features: ['Everything in Pro', 'Team access (5 seats)', 'Brand kit creator', 'Priority generation', 'API access', 'Custom color presets', 'Dedicated support'], cta: 'Contact Sales', popular: false },
];

function FloatingLogoCard({ config, delay = 0, className = '' }: { config: any; delay?: number; className?: string }) {
  const [svg, setSvg] = useState('');
  useEffect(() => {
    const s = generateLogoSVG(config);
    setSvg(svgToDataURL(s));
  }, []);
  return (
    <div
      className={`absolute glass rounded-2xl p-3 shadow-card animate-float ${className}`}
      style={{ animationDelay: `${delay}s`, animationDuration: `${5 + delay}s` }}
    >
      {svg && <img src={svg} alt={config.businessName} className="w-32 h-16 object-contain rounded-lg" />}
    </div>
  );
}

export default function Home() {
  const [demoIndex, setDemoIndex] = useState(0);
  const [demoSvg, setDemoSvg] = useState('');

  useEffect(() => {
    const config = DEMO_CONFIGS[demoIndex];
    const s = generateLogoSVG(config);
    setDemoSvg(svgToDataURL(s));
  }, [demoIndex]);

  useEffect(() => {
    const t = setInterval(() => setDemoIndex(i => (i + 1) % DEMO_CONFIGS.length), 3000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen bg-surface noise-overlay">
      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-accent-violet flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-display font-bold text-white text-lg tracking-tight">LogoStudio <span className="gradient-text">AI</span></span>
          </div>
          <div className="hidden md:flex items-center gap-1">
            {['Features', 'Styles', 'Pricing', 'FAQ'].map(item => (
              <a key={item} href={`#${item.toLowerCase()}`} className="btn-ghost text-sm">{item}</a>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login" className="btn-ghost text-sm">Sign in</Link>
            <Link href="/generator" className="btn-primary text-sm py-2 px-5">
              Start Free
            </Link>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative min-h-screen flex items-center pt-16 overflow-hidden grid-bg">
        {/* Background glows */}
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] rounded-full bg-brand-500/10 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-accent-violet/8 blur-[100px] pointer-events-none" />

        {/* Floating cards */}
        <FloatingLogoCard config={DEMO_CONFIGS[0]} delay={0} className="top-32 left-12 hidden xl:block" />
        <FloatingLogoCard config={DEMO_CONFIGS[1]} delay={1.5} className="top-24 right-16 hidden xl:block" />
        <FloatingLogoCard config={DEMO_CONFIGS[2]} delay={0.8} className="bottom-32 left-20 hidden xl:block" />
        <FloatingLogoCard config={DEMO_CONFIGS[3]} delay={2} className="bottom-40 right-12 hidden xl:block" />

        <div className="max-w-7xl mx-auto px-6 py-24 text-center relative z-10">
          <div className="section-tag mb-8 mx-auto w-fit">
            <Sparkles className="w-3 h-3" />
            <span>AI-Powered Brand Identity</span>
          </div>

          <h1 className="font-display font-bold text-5xl md:text-7xl lg:text-8xl text-white leading-[0.95] mb-6 tracking-tight">
            Create Stunning<br />
            <span className="gradient-text">AI Logos</span><br />
            in Seconds
          </h1>

          <p className="text-text-secondary text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Generate modern, professional, brand-ready logos for your business using AI.
            24+ styles, unlimited possibilities, commercial license included.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Link href="/generator" className="btn-primary text-base py-4 px-8 flex items-center gap-2 justify-center glow-border">
              <Sparkles className="w-5 h-5" />
              Generate Your Logo Free
              <ArrowRight className="w-4 h-4" />
            </Link>
            <button className="btn-secondary text-base py-4 px-8 flex items-center gap-2 justify-center">
              <Play className="w-4 h-4" />
              Watch Demo
            </button>
          </div>

          {/* Live demo preview */}
          <div className="relative max-w-xl mx-auto">
            <div className="glass rounded-3xl p-6 shadow-glow-sm">
              <div className="flex items-center gap-2 mb-4">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/60" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                  <div className="w-3 h-3 rounded-full bg-green-500/60" />
                </div>
                <span className="text-text-muted text-xs font-mono ml-2">LogoStudio AI — Live Preview</span>
              </div>
              <div className="bg-surface-2 rounded-2xl overflow-hidden aspect-video flex items-center justify-center relative">
                {demoSvg && (
                  <img
                    key={demoIndex}
                    src={demoSvg}
                    alt="Demo logo"
                    className="w-full h-full object-contain animate-fade-in"
                  />
                )}
                <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
                  {DEMO_CONFIGS.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setDemoIndex(i)}
                      className={`h-1.5 rounded-full transition-all duration-300 ${i === demoIndex ? 'bg-brand-500 w-6' : 'bg-white/20 w-1.5'}`}
                    />
                  ))}
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between text-xs text-text-muted">
                <span>Showing: <span className="text-brand-400">{DEMO_CONFIGS[demoIndex].businessName}</span> • {DEMO_CONFIGS[demoIndex].style}</span>
                <span className="flex items-center gap-1"><Zap className="w-3 h-3 text-amber-400" /> Generated in 1.2s</span>
              </div>
            </div>
          </div>

          <p className="text-text-muted text-sm mt-6">No credit card required • Free forever plan available</p>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="section-tag mx-auto mb-4 w-fit">Features</div>
          <h2 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">Everything you need to<br /><span className="gradient-text">brand your business</span></h2>
          <p className="text-text-secondary max-w-xl mx-auto">A complete logo design studio powered by AI, built for founders, creators, and agencies.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <div key={i} className="card p-6 group">
              <div className="w-10 h-10 rounded-xl bg-brand-500/15 border border-brand-500/20 flex items-center justify-center mb-4 group-hover:bg-brand-500/25 transition-colors">
                <f.icon className="w-5 h-5 text-brand-400" />
              </div>
              <h3 className="font-display font-semibold text-white mb-2">{f.title}</h3>
              <p className="text-text-secondary text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* STYLES SHOWCASE */}
      <section id="styles" className="py-24 bg-surface-1/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="section-tag mx-auto mb-4 w-fit">24+ Styles</div>
            <h2 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">A style for<br /><span className="gradient-text">every brand</span></h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {LOGO_STYLES.map((style) => (
              <Link key={style.id} href="/generator" className="card p-4 text-center hover:border-brand-500/40 group cursor-pointer">
                <div className="text-3xl mb-2 group-hover:scale-110 transition-transform">{style.icon}</div>
                <div className="font-medium text-white text-sm">{style.name}</div>
                <div className="text-text-muted text-xs mt-0.5">{style.description}</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="section-tag mx-auto mb-4 w-fit">Testimonials</div>
          <h2 className="font-display font-bold text-4xl text-white mb-4">Loved by <span className="gradient-text">10,000+</span> creators</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {TESTIMONIALS.map((t, i) => (
            <div key={i} className="card p-5">
              <div className="flex gap-1 mb-3">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-text-secondary text-sm leading-relaxed mb-4">&ldquo;{t.text}&rdquo;</p>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-500 to-accent-violet flex items-center justify-center text-white text-xs font-bold">{t.avatar}</div>
                <div>
                  <div className="text-white text-sm font-medium">{t.name}</div>
                  <div className="text-text-muted text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" className="py-24 bg-surface-1/30">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="section-tag mx-auto mb-4 w-fit">Pricing</div>
            <h2 className="font-display font-bold text-4xl text-white mb-4">Simple, <span className="gradient-text">transparent</span> pricing</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {PRICING.map((plan) => (
              <div key={plan.name} className={`card p-6 relative ${plan.popular ? 'border-brand-500/50 shadow-glow-sm' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand-500 text-white text-xs font-bold px-3 py-1 rounded-full">Most Popular</div>
                )}
                <div className="mb-5">
                  <h3 className="font-display font-bold text-white text-xl mb-1">{plan.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-white">${plan.price}</span>
                    <span className="text-text-muted text-sm">/{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-2.5 mb-6">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-text-secondary">
                      <Check className="w-4 h-4 text-brand-400 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href="/generator" className={`block text-center py-3 rounded-xl font-semibold text-sm transition-all ${plan.popular ? 'btn-primary' : 'btn-secondary'}`}>
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 max-w-4xl mx-auto px-6 text-center">
        <div className="glass rounded-3xl p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-mesh opacity-30" />
          <div className="relative z-10">
            <div className="section-tag mx-auto mb-6 w-fit">Get Started Today</div>
            <h2 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">
              Your brand identity<br /><span className="gradient-text">starts here</span>
            </h2>
            <p className="text-text-secondary mb-8 max-w-md mx-auto">Join thousands of entrepreneurs, creators, and agencies who trust LogoStudio AI for their brand identity.</p>
            <Link href="/generator" className="btn-primary text-base py-4 px-10 inline-flex items-center gap-2 glow-border">
              <Sparkles className="w-5 h-5" />
              Create Your Logo — It&apos;s Free
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-500 to-accent-violet flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-display font-bold text-white">LogoStudio AI</span>
          </div>
          <p className="text-text-muted text-sm">© {new Date().getFullYear()} LogoStudio AI. All rights reserved.</p>
          <div className="flex gap-4 text-text-muted text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
