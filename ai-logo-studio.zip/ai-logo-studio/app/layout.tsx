import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'LogoStudio AI — Create Stunning Logos in Seconds',
  description: 'Generate modern, professional, brand-ready logos for your business using AI. Premium logo design powered by artificial intelligence.',
  keywords: 'AI logo generator, logo design, brand identity, logo maker, business logo',
  openGraph: {
    title: 'LogoStudio AI — Create Stunning Logos in Seconds',
    description: 'AI-powered professional logo generation for modern brands.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-surface antialiased">
        {children}
      </body>
    </html>
  );
}
