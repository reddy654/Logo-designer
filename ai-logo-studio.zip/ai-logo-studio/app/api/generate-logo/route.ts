import { NextRequest, NextResponse } from 'next/server';
import { generateMultipleLogos } from '@/lib/logo-generator';
import type { LogoConfig } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const config: LogoConfig = await req.json();

    if (!config.businessName?.trim()) {
      return NextResponse.json({ error: 'Business name is required' }, { status: 400 });
    }

    const logos = await generateMultipleLogos(config);

    return NextResponse.json({ success: true, logos });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
